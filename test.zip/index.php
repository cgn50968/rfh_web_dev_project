<!DOCTYPE html>
<html lang="de">

<head>
	
	<title>Web-Database</title>
	<meta charset="utf-8"/>
	
	<link rel="stylesheet" href="css/style.css" type="text/css" />
	<link rel="stylesheet" href="./css/jquery-ui-1.10.4.custom.css" />
	<link rel="stylesheet" href="./css/application.css" />
    <script src="./js/jquery-1.10.2.js" type="text/javascript"></script>
    <script src="./js/jquery-ui-1.10.4.custom.js" type="text/javascript"></script>
    <script src="./js/wiki.wikilist.js" type="text/javascript"></script>
	<script src="./js/wiki.wikidetails.js" type="text/javascript"></script>		
    <script src="./js/wiki.errordialog.js" type="text/javascript"></script>
	<script src="./js/wiki.deletedialog.js" type="text/javascript"></script>		
	<script src="./js/wiki.editdialog.js" type="text/javascript"></script>
	<script src="./js/wiki.application.js" type="text/javascript"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> <!--mobile Endgeräte nutzen . . . . -->

</head>


<body class="body">

	<header class="mainHeader">
		<!--<img src="img/info_logo50.png">-->
		
		<nav>
			<ul>
				<li><a href="#">Start</a></li>
				<li><a href="#">Suche</a></li>
				<li><a href="#">Editor</a></li>
				<li><a href="#">Kontakt</a></li>
			</ul>
		</nav>
	</header>
	
	<div class="mainContent">
		<div class="content">
			<article class="topContent">
				<header>
					<h1><a href="#" title="First post">Einträge:</a></h1>
				</header>
				
				<div class="response-table">
					<!--Hier soll der Inhalt der Requests stehen:-->
					<!-------------------------------------------
					  HTML Elements für Widget "wiki.wikilist.js" 
					 --------------------------------------------->
					<div id="wiki_list" class="ui-widget">  <!-- verlinkung mit application.js -->   
						<div>		<!-- 2 Klassen - wiki und template -->
							<table class="wiki template">
							<tr>
							  <td id="heading">Autor</td>
							  <td id="fieldname" class="author"></td>
							  <td id="fieldname" class="category"></td>
							  <td id="fieldname" class="title"></td>
							  <td id="heading">Erstelldatum</td>
							  <td id="fieldname" class="creation_date"></td>
							  <td id="heading">Ablaufdatum</td>
							  <td id="fieldname" class="expiration_date"></td>
							  <td id="heading"><a class="edit_wiki" href="#">Bearbeiten</a></td>		<!-- Tag für Bearbeiten -->
							  <td id="heading"><a class="delete_wiki" href="#">Löschen</a></td>
							</tr>
							</table>
						</div>
					</div>
				</div>
					
					<!-----------------------------------------------------------------
					 Definition des HTML Elements für das Widget "wiki.wikidetails.js" 
					------------------------------------------------------------------->
					<div id="wiki_details" class="ui-widget">
						<span>Autor</span>
						<span class="author"></span>
						<span>|</span>
						<span>Erstelldatum</span>
						<span class="creation_date"></span>
						<span>Ablaufdatum</span>
						<span class="expiration_date"></span>
						<span class="title"></span>
						<span class="notes"></span>
					</div>
						
					<!-----------------------------------------------------------------
					 Definition des HTML Elements für das Widget "wiki.errordialog.js" 
					------------------------------------------------------------------->
					<div id="error_dialog" title="Fehler" class=ui-widget">
						<div class="message"></div>								<!-- class message für Error Code -->
					</div>
					
					<!------------------------------------------------------------------
					 Definition des HTML Elements für das Widget "wiki.deletedialog.js" 
					-------------------------------------------------------------------->
					<div id="delete_dialog" title="Wiki löschen" class="ui-widget">
						<div> Möchten Sie das Wiki wirklich löschen?</div>
					</div>
					
					<!----------------------------------------------------------------
					 Definition des HTML Elements für das Widget "wiki.editdialog.js" 
					------------------------------------------------------------------>
					
					<div id="edit_dialog" title="Wiki bearbeiten" class="ui-widget">
					  <form>
						<table>
						  <tr>
							<td/>
							<td colspan="3"><span class="validation_message ui-state-error-text"></span></td>
						  </tr>
						  <tr>
							<td><label for="author_field">Autor:</label></td>
							<td><label for="creation_date_field">Erstelldatum:</label></td>
							<td><label for="expiration_date_field">Gültigkeitsdatum:</label></td>
						  </tr>
						  <tr>
							<td><input id="author_field" type="text"/></td>
							<td><input id="creation_date_field" type="text"/></td>
							<td><input id="expiration_date_field" type="text"/></td>
						  </tr>
						  <tr>
							<td><label for="category_field">Kategorie:</label></td>    
							<td colspan="2"><label for="title_field">Titel:</label></td>    
						  </tr>
						  <tr>
							<td><input id="category_field" type="text"/></td>
							<td colspan="2"><input id="title_field" type="text"/></td>
						  </tr>
						  <tr>
							<td><label for="notes_field">Beschreibung:</label></td>          
							<td colspan="3"><textarea id="notes_field"></textarea></td>
						  </tr>
						</table>
					  </form>
					</div>
					
				</content>
				
				<!--<footer>
					<p class="post-info">Autor: Heiko Herder</p>
				</footer>-->
				
			</article>
			
			<!--<article class="bottomContent">
				<header>
					<h1><a href="#" title="Second post">Second post</a></h1>
				</header>
				
				<footer>
					<p class="post-info">Autor: Heiko Herder</p>
				</footer>
				
				<content>
					<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
					<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
				</content>
				
			</article>-->
		</div>	
	</div>

	<aside class="top-sidebar">
		<article>
			<h2>Schnellsuche</h2>
			<p>
				
				<form action='index.php' method='POST'>
					<input type='text' name='suchfeld'>
					<input type='submit' name='suche_enter' value='Suchen'>
				</form>
				<br>
				<?php
					if (isset($_POST['suche_enter']))
					{
						$host = "localhost";
						$user = "root";
						$pass = "";
						$con = mysql_connect($host,$user,$pass) or die(mysql_error());
						mysql_select_db("wiki",$con) or die(mysql_error());
						$suchbegriff = trim(htmlentities(stripslashes(mysql_real_escape_string($_POST['suchfeld']))));
						
						$sql = "
							SELECT
								category, title, notes, author
							FROM
								wiki
							WHERE
								category LIKE '%$suchbegriff%'
								OR
								title LIKE '%$suchbegriff%'
								OR
								notes LIKE '%$suchbegriff%'
								OR
								author LIKE '%$suchbegriff%'
							ORDER BY
								category, title, author, notes
							";
						$query = mysql_query($sql);
						
						echo "<ul>";
						while($row = mysql_fetch_assoc($query))
						{
							$category = $row['category'];
							$title = $row['title'];
							$notes = $row['notes'];
							$author = $row['author'];
							
							echo "<li>$category $title $notes $author</li>";
						}
						echo "<ul>";
					}
									
				?>
			</p>
		</article>
	</aside>
	
	<!--<aside class="middle-sidebar">
		<article>
			<h2>Middle sidebar</h2>
			<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr.</p>
			<button type="button" onclick="alert('SUCHEN')">Starten</button>
		</article>
	</aside>-->
	
	<aside class="bottom-sidebar">
		<article>
			<h2>Letzte Einträge</h2>
			<p>Hier stehen die letzten drei Einträge (Titel)</p>
			
		</article>
	</aside>
	
	<footer class="mainFooter">
		<p>Copyright &copy; 2014 Herder, Ordon</p>
	</footer>
	
</body>


</html>
