<?php
	class CreateWikiResult {
	
	public $id;
	public $status_code;
	public $validation_messages = array();
	}
?>
	